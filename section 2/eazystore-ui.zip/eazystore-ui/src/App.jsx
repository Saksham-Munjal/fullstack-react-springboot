import Header from "./components/HeaderComponent.jsx";


function App() {  
    return(
        <Header />
    );
}

export default App
